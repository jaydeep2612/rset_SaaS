<?php

namespace App\Filament\Resources\KitchenQueueResource\Pages;

use App\Filament\Resources\KitchenQueueResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateKitchenQueue extends CreateRecord
{
    protected static string $resource = KitchenQueueResource::class;
}
